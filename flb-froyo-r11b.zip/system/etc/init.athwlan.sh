#!/system/bin/sh
chmod 750 /system/wifi/*.sh
setprop wlan.default.dns1 8.8.4.4
setprop wifi.interface wlan0
